@echo off
chcp 65001 >nul
node "%~dp0tools\install-claude-hooks.js" %*
echo.
pause
